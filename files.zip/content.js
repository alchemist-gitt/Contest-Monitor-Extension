// content.js
// Stage 1: watch the contest page for visibility/focus changes and report
// them to the background service worker. This script does NOT read page
// content, keystrokes, clipboard, or any contest-specific data — it only
// observes two standard browser events for the tab it's injected into.

function sendEvent(type) {
  const event = {
    type,                   // "PAGE_HIDDEN" | "PAGE_VISIBLE" | "WINDOW_BLUR" | "WINDOW_FOCUS"
    timestamp: Date.now(),  // captured at the moment the event fires
    url: location.href
  };

  // The extension context can be invalidated (e.g. on reload/update) while
  // the page is still open. Don't let that throw and break the contest page.
  try {
    chrome.runtime.sendMessage(event);
  } catch (err) {
    console.warn("[contest-monitor] could not send event:", err);
  }
}

document.addEventListener("visibilitychange", () => {
  sendEvent(document.hidden ? "PAGE_HIDDEN" : "PAGE_VISIBLE");
});

window.addEventListener("blur", () => sendEvent("WINDOW_BLUR"));
window.addEventListener("focus", () => sendEvent("WINDOW_FOCUS"));

// Log the starting state so the very first entry in the log is a baseline,
// not a gap.
sendEvent(document.hidden ? "PAGE_HIDDEN" : "PAGE_VISIBLE");
